//Script enables activation of the darkMode

let makeDark = document.getElementById("makeDark");
let makeBright = document.getElementById("makeBright");

if (makeDark) {
  makeDark.onclick = function() {
    darkMode(true);
  };
}

if (makeBright) {
  makeBright.onclick = function() {
    darkMode(false);
  };
}

function darkMode(c) {
    //  adds class to elemets which styles it DARK
    
  if (c) {
    console.log("dark mode on");
  } else {
    console.log("dark mode off");
  }
  
  //REFERNECE: https://stackoverflow.com/questions/7184562/how-to-get-elements-with-multiple-classes
  //Selection of the elemetns that will be affected by the darkMode
  let allElelmens = document.querySelectorAll(
    "body, main, button, a, h2, img, .gridArea, .app, .fpTitleDiv__text, .fpTitleDiv__text .redText, #fpLogoDiv, .progress_bar, .cafe_main, .cafe_main__item, .cafe_short, .must_see_main, .must_see_main__item .must_see_short, #apps__label, #underground__label, #menu__label"
  );
  // If darkMode true then darkMode-on calss is added to queried elements, otherwise it is being removed
  for (let i=0; i<allElelmens.length; i++){
    if (c) {
      allElelmens[i].classList.add("darkMode-on");
    } else {
      allElelmens[i].classList.remove("darkMode-on");
    };
  };
}